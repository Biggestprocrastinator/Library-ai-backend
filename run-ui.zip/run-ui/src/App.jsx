import LibraryAssistant from "./LibraryAssistant";

export default function App() {
  return <LibraryAssistant />;
}
